package com.codingdojo.TGA.Models;

public class Provincias {
	public static final String[] provincias = { "Iquique", "Tamarugal", "Antofagasta", "El Loa", "Tocopilla", "Atacama",
			"Chañaral", "Copiapó", "Coquimbo", "Elqui", "Limarí", "Isla de Pascua", "Los Andes", "Marga Marga",
			"Petorca", "Quillota", "San Antonio", "San Felipe de Aconcagua", "Valparaíso", "Chacabuco", "Cordillera",
			"Maipo", "Melipilla", "Metropolitana", "Ñuñoa", "Pedro Aguirre Cerda", "Puente Alto", "San Miguel",
			"Santiago", "Cachapoal", "Cardenal", "Caro", "Colchagua", "O'Higgins", "Cauquenes"

			, "Curicó", "Linares", "Maule", "Talca", "Diguillín", "Itata", "Ñuble", "Punilla", "Arauco", "Biobío",
			"Concepción", "Ñuble", "Cautín", "Malleco", "Valdivia", "Ranco", "Chiloé", "Llanquihue", "Osorno", "Palena",
			"Aysén", "Coyhaique" };

}
