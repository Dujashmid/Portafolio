const dropArea = document.querySelector(".drop-area");
const dragText = dropArea.querySelector("h2");
const button = dropArea.querySelector("button");
const input = dropArea.querySelector("input-file");

button.addEventListener("click", (e) =>{
    console.log("click");
});